package com.asen.test;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = Integer.parseInt(scanner.nextLine());
        ArrayList<OpinionPoll> people = new ArrayList<>();

        for (int i = 0; i < n; i++) {
            String[] token = scanner.nextLine().split("\\s+");
            OpinionPoll opinionPoll = new OpinionPoll(token[0], Integer.parseInt(token[1]));
            people.add(opinionPoll);
        }
        people.stream().filter(person->person.getAge()>30).
                sorted(Comparator.comparing(OpinionPoll::getName)).
                forEach(e-> System.out.println(e.getName()+" - "+e.getAge()));

//       Department department=new Department();
//        for (int i = 0; i < n; i++) {
//            String[] token = scanner.nextLine().split("\\ss+");
//            Employee employee;
//            if (token.length == 4) {
//                employee = new Employee(token[0], Double.parseDouble(token[1]), token[2], token[3]);
//            } else if (token.length == 6) {
//                employee = new Employee(token[0], Double.parseDouble(token[1]), token[2], token[3], token[4], Integer.parseInt(token[5]));
//            } else {
//                try {
//                    int age = Integer.parseInt(token[4]);
//                    employee = new Employee(token[0], Double.parseDouble(token[1]), token[2], token[3], age);
//                } catch (NumberFormatException eX) {
//                    employee = new Employee(token[0], Double.parseDouble(token[1]), token[2], token[3], token[4]);
//                }
//            }
//            department.addEMployeee(employee);
//        }

    }
}
