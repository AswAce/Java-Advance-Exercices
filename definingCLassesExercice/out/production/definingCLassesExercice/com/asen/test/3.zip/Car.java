package com.asen.test;

public class Car {
    private String model;
    private double fuelAMount;
    private double fuelCostPerOneKM;
    private int distanceTraveled;

    public Car(String model, double fuelAMount, double fuelCostPerOneKM) {
        this.model = model;
        this.fuelAMount = fuelAMount;
        this.fuelCostPerOneKM = fuelCostPerOneKM;
        this.distanceTraveled = 0;
    }


    public String getModel() {
        return model;
    }

    public double getFuelAMount() {
        return fuelAMount;
    }

    public double getFuelCostPerOneKM() {
        return fuelCostPerOneKM;
    }

    public int getDistanceTraveled() {
        return distanceTraveled;
    }

    public void checkCar(int amountOfKm) {
        if (this.fuelAMount - (amountOfKm * this.fuelCostPerOneKM)>=0){
        this.fuelAMount -= amountOfKm * this.fuelCostPerOneKM;
        this.distanceTraveled += amountOfKm;}

       else  {
            System.out.println("Insufficient fuel for the drive");
        }
    }

    @Override
    public String toString() {

        return String.format("%s %.2f %s ", model, fuelAMount ,distanceTraveled);
    }
}
