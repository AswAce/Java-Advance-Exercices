package com.asen.test;

import java.util.ArrayList;
import java.util.Comparator;

public class Department {
    private String departmentName;
    private  ArrayList<Employee> employeess;



    public Department(String departmentName) {
        this.departmentName = departmentName;
        this.employeess=new ArrayList<>();

    }

    public String getDepartmentName() {
        return departmentName;
    }

    public ArrayList<Employee> getEmployeess() {
        return this.employeess;
    }
    public  double getAvrage(){
        return  this.employeess.stream().mapToDouble(Employee::getSalary).average().orElse(0.0);
    }
}