package com.asen.test;

import java.util.*;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = Integer.parseInt(scanner.nextLine());
        Map<String, Department> departments = new HashMap<>();
//        ArrayList<OpinionPoll> people = new ArrayList<>();
//        for (int i = 0; i < n; i++) {
//            String[] token = scanner.nextLine().split("\\s+");
//            OpinionPoll opinionPoll = new OpinionPoll(token[0], Integer.parseInt(token[1]));
//            people.add(opinionPoll);
//        }
//        people.stream().filter(person->person.getAge()>30).
//                sorted(Comparator.comparing(OpinionPoll::getName)).
//                forEach(e-> System.out.println(e.getName()+" - "+e.getAge()));


        for (int i = 0; i < n; i++) {
            Employee employee;

            String[] token = scanner.nextLine().split("\\s+");
String department=token[3];
            if (token.length == 4) {
                employee = new Employee(token[0], Double.parseDouble(token[1]), token[2], department);
            } else if (token.length == 6) {
                employee = new Employee(token[0], Double.parseDouble(token[1]), token[2], department, token[4], Integer.parseInt(token[5]));

            } else {
                try {
                    int z = Integer.parseInt(token[4]);
                    employee = new Employee(token[0], Double.parseDouble(token[1]), token[2], department, z);


                } catch (Exception ex) {
                    employee = new Employee(token[0], Double.parseDouble(token[1]), token[2], department, token[4]);

                }

            }
            departments.putIfAbsent(department, new Department(department));
          departments.get(department).getEmployeess().add(employee);

        }
        Department  deparmentMax = departments.entrySet().stream().

                max(Comparator.comparingDouble(l -> l.getValue().getAvrage())).get().getValue();
        System.out.println("Highest Average Salary: "+deparmentMax.getDepartmentName());

        deparmentMax.getEmployeess().stream().
                sorted(Comparator.comparingDouble(Employee::getSalary).reversed()).
                forEach(e-> System.out.println(e.toString()));

    }

}
