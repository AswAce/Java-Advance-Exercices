package com.asen.test;

import java.util.*;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = Integer.parseInt(scanner.nextLine());
        List<Car> cars = new ArrayList<>();

//
        for (int i = 0; i < n; i++) {
            String[] token = scanner.nextLine().split("\\s+");
            String model = token[0];
            String engine = token[2];
            int cargoWeight = Integer.parseInt(token[3]);
            String cargo = token[4];
            Car car = new Car(model, engine, cargoWeight, cargo);
            for (int j = 0; j < 8; j += 2) {
                Tires tires = new Tires(Double.parseDouble(token[5 + j]), Integer.parseInt(token[5 + j + 1]));
                car.addTire(tires);
            }
            cars.add(car);
        }
        String command = scanner.nextLine();
        if (command.equals("fragile")) {
            for (Car car : cars) {
                boolean tire = false;
                if (car.getCargo().equals("fragile")) {
                    for (int i = 0; i < 4; i++) {
                        if (car.getTires().get(i).getTirePressure() < 1) {
                            tire = true;
                            break;
                        }
                    }
                }
                if (tire) {
                    System.out.println(car.getModel());
                }
            }
        } else if (command.equals("flamable")) {
            for (Car car : cars) {
                if (car.getCargo().equals("flamable") && Integer.parseInt(car.getEngine()) > 250) {
                    System.out.println(car.getModel());
                }
            }


        }


    }
}

