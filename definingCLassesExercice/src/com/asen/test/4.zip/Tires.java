package com.asen.test;

public class Tires {
    private  double TirePressure;
    private  int TireAge;

    public Tires(double tirePressure, int tireAge) {
        TirePressure = tirePressure;
        TireAge = tireAge;
    }

    public double getTirePressure() {
        return TirePressure;
    }

    public int getTireAge() {
        return TireAge;
    }
}
