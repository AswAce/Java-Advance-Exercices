package com.asen.test;

import java.util.ArrayList;

public class Car {
    private String model;
    private String engine;
    private int cargoWeight;
    private String cargo;
    private ArrayList<Tires> tires;

    public Car(String model, String engine, int cargoWeight, String cargo) {
        this.model = model;
        this.engine = engine;
        this.cargoWeight = cargoWeight;
        this.cargo = cargo;
        this.tires = new ArrayList<>();
    }
    public  void  addTire(Tires tires){
        this.tires.add(tires);
    }

    public String getModel() {
        return model;
    }

    public String getEngine() {
        return engine;
    }

    public int getCargoWeight() {
        return cargoWeight;
    }

    public String getCargo() {
        return cargo;
    }

    public ArrayList<Tires> getTires() {
        return tires;
    }
}
